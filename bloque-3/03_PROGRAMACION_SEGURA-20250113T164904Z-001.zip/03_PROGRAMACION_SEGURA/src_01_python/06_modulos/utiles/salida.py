def saludo(nombre="Anónimo"):
    print(f"Hola {nombre}")

