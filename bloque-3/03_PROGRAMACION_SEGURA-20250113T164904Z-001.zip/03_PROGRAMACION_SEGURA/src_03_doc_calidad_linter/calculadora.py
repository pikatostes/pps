def suma(a:int,b:int) ->int:
    return a + b

def resta(a,b):
    """ Resta dos numeros."""
    return a-b
