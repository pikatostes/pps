CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY, 
    email TEXT,
    username TEXT,
    password TEXT);

