INSERT INTO users (id, email, username, password)
    VALUES
    (1,'artist@local.com', 'artist', '1234'),
    (2,'boss@local.com', 'boss', '123456'),
    (3,'carpet@local.com', 'carpet', '123478');
