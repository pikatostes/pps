# Para probar instalación Python
print("Hola Mundo")  # print de prueba