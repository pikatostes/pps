# main.py
import argparse

from inventario import agregar_producto, eliminar_producto
from inventario import consultar_producto, listar_inventario

def main():
    parser = argparse.ArgumentParser(description="Gestión inventario.")

    # Con choice dammos las valores permitidos
    parser.add_argument("accion", choices=["agregar", "eliminar", "consultar",
                        "listar"], help="Acción a realizar.")
    # Paráemtros "con nombre", pueden aparecer en cualquier orden 
    parser.add_argument("--producto", type=str, help="Nombre del producto.")
    parser.add_argument("--cantidad", type=int, help="Cantidad del producto.")

    args = parser.parse_args()
    accion = args.accion
    producto = args.producto
    cantidad = args.cantidad

    inventario = {
        'manzanas': 2,
        'peras': 1,
    }

    try:
        print("Inventario inicial: ", inventario)
        if accion == "agregar":
            if not producto or cantidad is None:
                print("antes de la excepción")
                raise ValueError("Especificar producto y cantidad.")

            # global inventario
            
            inventario = agregar_producto(inventario,producto, cantidad)
            print(f"Producto agregado: {producto} ({cantidad}).")


        elif accion == "eliminar":
            if not producto or cantidad is None:
                raise ValueError("Especificar producto y antidad a eliminar.")
            inventario = eliminar_producto(inventario, producto, cantidad)
            print(f"Producto eliminado: {producto} ({cantidad}).")

        elif accion == "consultar":
            if not producto:
                raise ValueError("Especificar producto para consultar.")
            cantidad_disponible = consultar_producto(inventario, producto)
            print(f"Cantidad de '{producto}': {cantidad_disponible}")

        elif accion == "listar":
            productos = listar_inventario(inventario)
            if productos:
                print("Inventario actual:")
                for prod, cant in productos.items():
                    print(f"- {prod}: {cant}")
            else:
                print("El inventario está vacío.")
        print("Inventario final: ", inventario)
    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
