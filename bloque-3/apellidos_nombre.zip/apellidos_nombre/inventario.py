# modulo_inventario.py
import io



def agregar_producto(inventario, producto, cantidad):
    """Agrega una cantidad de un producto al inventario."""
    debug = False
    if cantidad <= 0:
        raise ValueError("La cantidad debe ser mayor a 0.")
    if producto in inventario:
        inventario[producto] += cantidad
    else:
        inventario[producto] = cantidad

    return inventario

def eliminar_producto(inventario, producto, cantidad):
    
    if producto not in inventario:
        raise KeyError(f"El producto '{producto}' no existe en el inventario.")
    if cantidad > inventario[producto]:
        txt= f"No hay bastante existencias de {producto}."
        raise ValueError(txt)
    inventario[producto] -= cantidad
    if inventario[producto] == 0:
        del inventario[producto]

    return inventario


def consultar_producto(inventario, producto):
    # Devuelve la cantidad de  producto 
    # o 0 si no está en inventario
    return inventario.get(producto, 0)


def listar_inventario(inventario):
    return inventario

if __name__ == "__main__":
    inventario = {
        "manzanas": 10,
        "naranjas": 5
    }
    print(consultar_producto(inventario, "naranjas"))
    print(consultar_producto(inventario, "peras"))
  
